import sqlite3

conn = sqlite3.connect("avm_base.sqlite")
cursor = conn.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS nacimientos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provincia_nombre TEXT NOT NULL,
        departamento_nombre TEXT NOT NULL,
        anio INTEGER NOT NULL,
        nacimientos_cantidad INTEGER NOT NULL
    )
""")

conn.commit()
conn.close()

print("Tabla 'nacimientos' verificada o creada correctamente.")