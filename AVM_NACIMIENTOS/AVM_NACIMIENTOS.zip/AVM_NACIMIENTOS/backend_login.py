from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import sqlite3
import json
import os

class SimpleLoginHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        if self.path == "/login":
            length = int(self.headers.get('Content-Length'))
            body = self.rfile.read(length).decode()
            data = urllib.parse.parse_qs(body)

            usuario = data.get("usuario", [""])[0]
            contrasena = data.get("contrasena", [""])[0]

            conn = sqlite3.connect("avm_base.sqlite")
            cursor = conn.cursor()
            cursor.execute("SELECT tipo FROM usuarios WHERE usuario=? AND contrasena=?", (usuario, contrasena))
            row = cursor.fetchone()
            conn.close()

            if row:
                destino = "usuario.html" if row[0] == "usuario" else "admin.html"
                self.send_response(303)
                self.send_header("Location", "/" + destino)
                self.end_headers()
            else:
                self.send_response(303)
                self.send_header("Location", "/index.html")
                self.end_headers()

        elif self.path.startswith("/api/nacimientos/"):
            id_str = self.path.split("/")[-1]
            try:
                id_int = int(id_str)
            except ValueError:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"ID invalido")
                return

            length = int(self.headers.get('Content-Length'))
            body = self.rfile.read(length).decode()
            data = json.loads(body)

            conn = sqlite3.connect("avm_base.sqlite")
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE nacimientos SET 
                    provincia_nombre = ?, 
                    departamento_nombre = ?, 
                    anio = ?, 
                    nacimientos_cantidad = ? 
                WHERE id = ?
            """, (
                data.get("provincia"),
                data.get("departamento"),
                data.get("anio"),
                data.get("cantidad"),
                id_int
            ))
            conn.commit()
            conn.close()

            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Registro actualizado")

    def do_GET(self):
        if self.path.startswith("/api/nacimientos"):
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            offset = int(query.get("offset", [0])[0])

            conn = sqlite3.connect("avm_base.sqlite")
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, provincia_nombre, departamento_nombre, anio, nacimientos_cantidad 
                FROM nacimientos 
                LIMIT 20 OFFSET ?
            """, (offset,))
            filas = cursor.fetchall()
            conn.close()

            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps([
                {
                    "id": f[0],
                    "provincia": f[1],
                    "departamento": f[2],
                    "anio": f[3],
                    "cantidad": f[4]
                } for f in filas
            ]).encode("utf-8"))
            return

        filepath = self.path.strip("/")
        if filepath == "":
            filepath = "index.html"

        ruta = os.path.join("templates", filepath)
        try:
            with open(ruta, "rb") as file:
                self.send_response(200)
                if ruta.endswith(".html"):
                    self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(file.read())
        except FileNotFoundError:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Archivo no encontrado")

    def do_DELETE(self):
        if self.path.startswith("/api/nacimientos/"):
            id_str = self.path.split("/")[-1]
        try:
            id_int = int(id_str)
        except ValueError:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"ID invalido")
            return

        conn = sqlite3.connect("avm_base.sqlite")
        cursor = conn.cursor()
        cursor.execute("DELETE FROM nacimientos WHERE id = ?", (id_int,))
        conn.commit()
        conn.close()

        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"Registro eliminado")


if __name__ == "__main__":
    server = HTTPServer(("localhost", 8000), SimpleLoginHandler)
    print("Servidor corriendo en http://localhost:8000")
    server.serve_forever()
